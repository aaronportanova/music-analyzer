import os
import sys
import time
import tkinter as tk
from tkinter import filedialog, scrolledtext, ttk, messagebox
import csv
import re
from mutagen.id3 import ID3, ID3NoHeaderError
from mutagen.mp4 import MP4
from mutagen.flac import FLAC

# Window size settings (percentage of screen size)
WINDOW_WIDTH_PERCENT = 30       # Percentage of screen width
WINDOW_HEIGHT_PERCENT = 80      # Percentage of screen height
MIN_WIDTH_PERCENT = 10          # Minimum width percentage
MIN_HEIGHT_PERCENT = 10         # Minimum height percentage

ROW_FRAME_HEIGHT = 600          # Height of the row entry frame

# Pop-up window size settings
POPUP_WIDTH_PERCENT = 40        # Percentage of screen width for pop-up windows
POPUP_HEIGHT_PERCENT = 60       # Percentage of screen height for pop-up windows
POPUP_MIN_WIDTH_PERCENT = 20    # Minimum width percentage for pop-up windows
POPUP_MIN_HEIGHT_PERCENT = 20   # Minimum height percentage for pop-up windows

# Theme color settings
MAIN_BG_COLOR = "#1F1630"
ENTRY_BG_COLOR = "#DCDAD5"
BUTTON_BG_COLOR = "#631770"
HOVER_COLOR = "#3db6f2" #"#47cf38"
TEXT_COLOR = "#FFFFFF"         
INPUT_TEXT_COLOR = "#000000"
ACCENT_COLOR = "#D3D3D3"
TAB_BG_COLOR = "#1F1630"
TAB_TEXT_COLOR = "#000000"


def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    
    return os.path.join(base_path, relative_path)


class WindowManagement:
    @staticmethod
    def center_window(window):
        """Center the given window on the screen"""
        window.update_idletasks()
        width = window.winfo_width() or (window.winfo_screenwidth() * POPUP_MIN_WIDTH_PERCENT / 100)
        height = window.winfo_height() or (window.winfo_screenheight() * POPUP_MIN_HEIGHT_PERCENT / 100)
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        window.geometry(f"{width}x{height}+{x}+{y}")
        window.minsize(int(screen_width * POPUP_MIN_WIDTH_PERCENT / 100),
                      int(screen_height * POPUP_MIN_HEIGHT_PERCENT / 100))

class MenuBar:
    def __init__(self, root, app):
        self.root = root
        self.app = app
        self.menu_bar = tk.Menu(self.root, bg=MAIN_BG_COLOR, fg=TEXT_COLOR, activebackground=HOVER_COLOR, activeforeground=TEXT_COLOR)
        self.root.config(menu=self.menu_bar)
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.txt_dir = os.path.join(self.script_dir, "txt")
        self.setup_menus()

    def setup_menus(self):
        file_menu = tk.Menu(self.menu_bar, tearoff=0, bg=MAIN_BG_COLOR, fg=TEXT_COLOR, activebackground=HOVER_COLOR)
        self.menu_bar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Exit", command=self.exit_application)

        help_menu = tk.Menu(self.menu_bar, tearoff=0, bg=MAIN_BG_COLOR, fg=TEXT_COLOR, activebackground=HOVER_COLOR)
        self.menu_bar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)
        help_menu.add_command(label="Example Prompts", command=self.show_example_prompts)

    def exit_application(self):
        if messagebox.askokcancel("Quit", "Quit the application?", parent=self.root):
            self.root.quit()
            self.root.destroy()

    def show_about(self):
        popup = tk.Toplevel(self.root)
        popup.configure(bg=MAIN_BG_COLOR)
        popup.title("About")
        popup.geometry(f"{int(self.root.winfo_screenwidth() * POPUP_WIDTH_PERCENT / 100)}x{int(self.root.winfo_screenheight() * POPUP_HEIGHT_PERCENT / 100)}")
        
        # Set the window icon for this popup
        self.app.set_window_icon(popup)

        # Use Courier New 12pt for better readability
        text = scrolledtext.ScrolledText(popup, wrap=tk.WORD, bg=ENTRY_BG_COLOR, fg=INPUT_TEXT_COLOR, font=('Courier New', 12))
        text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        try:
            with open(resource_path(os.path.join("txt", "about.txt")), "r", encoding="utf-8") as f:
                text.insert(tk.END, f.read())
        except FileNotFoundError:
            text.insert(tk.END, f"About file (about.txt) not found in {self.txt_dir}!")
        except Exception as e:
            text.insert(tk.END, f"Error reading about.txt: {str(e)}")
        
        ttk.Button(popup, text="Close", command=popup.destroy, style="Custom.TButton").pack(pady=5)
        WindowManagement.center_window(popup)

    def show_example_prompts(self):
        popup = tk.Toplevel(self.root)
        popup.configure(bg=MAIN_BG_COLOR)
        popup.title("Example Prompts")
        popup.geometry(f"{int(self.root.winfo_screenwidth() * POPUP_WIDTH_PERCENT / 100)}x{int(self.root.winfo_screenheight() * POPUP_HEIGHT_PERCENT / 100)}")
        
        # Set the window icon for this popup
        self.app.set_window_icon(popup)
        
        # Use Calibri 14pt for better readability
        text = scrolledtext.ScrolledText(popup, wrap=tk.WORD, bg=ENTRY_BG_COLOR, fg=INPUT_TEXT_COLOR, font=('Calibri', 14))
        text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        try:
            with open(resource_path(os.path.join("txt", "example_prompts.txt")), "r", encoding="utf-8") as f:
                text.insert(tk.END, f.read())
        except FileNotFoundError:
            text.insert(tk.END, f"Example Prompts file (example-prompts.txt) not found in {self.txt_dir}!")
        except Exception as e:
            text.insert(tk.END, f"Error reading example-prompts.txt: {str(e)}")
        
        ttk.Button(popup, text="Close", command=popup.destroy, style="Custom.TButton").pack(pady=5)
        WindowManagement.center_window(popup)

class MusicAnalyzer:
    def __init__(self, root):
        self.root = root
        self.root.title("Music Collection Analyzer")
        self.root.configure(bg=MAIN_BG_COLOR)

        # Calculate window position and size up front
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        window_width = int(screen_width * WINDOW_WIDTH_PERCENT / 100)
        window_height = int(screen_height * WINDOW_HEIGHT_PERCENT / 100)
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        
        # Center the window
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")
        self.root.minsize(int(screen_width * MIN_WIDTH_PERCENT / 100),
                        int(screen_height * MIN_HEIGHT_PERCENT / 100))
    
        # Set window icon
        self.set_window_icon(self.root)

        # Apply ttk styling
        self.style = ttk.Style()
        self.style.theme_use('clam')  # Use a modern theme as base
        self.style.configure("TLabel", background=MAIN_BG_COLOR, foreground=TEXT_COLOR, padding=6, font=('Arial', 10))
        self.style.configure("TFrame", background=MAIN_BG_COLOR)
        self.style.configure("TNotebook", background=MAIN_BG_COLOR, tabmargins=0)
        self.style.configure("TNotebook.Tab", background=TAB_BG_COLOR, foreground=TAB_TEXT_COLOR, padding=[6, 5],
                            activebackground=BUTTON_BG_COLOR, activeforeground=TEXT_COLOR)
        self.style.configure("Custom.TButton", background=BUTTON_BG_COLOR, foreground=TEXT_COLOR, padding=3,
                            font=('Helvetica', 10, 'bold'))
        self.style.map("Custom.TButton",
                    background=[('active', HOVER_COLOR)],
                    foreground=[('active', TEXT_COLOR)])
        self.style.configure("TEntry", fieldbackground=ENTRY_BG_COLOR, foreground=INPUT_TEXT_COLOR, insertcolor=INPUT_TEXT_COLOR)
        self.style.configure("TScrollbar", background=MAIN_BG_COLOR, troughcolor=ENTRY_BG_COLOR, arrowcolor=TEXT_COLOR,
                            highlightbackground=HOVER_COLOR,
                            highlightcolor=HOVER_COLOR,  # Fixed typo: highlighcolor -> highlightcolor
                            highlightthickness=0)

        # Custom style for heading labels (no background, bold Arial)
        self.style.configure("Heading.TLabel", background=MAIN_BG_COLOR, foreground=TEXT_COLOR, font=('Arial', 11, 'bold'))

        # New style for white background frames
        self.style.configure("WhiteFrame.TFrame", background=MAIN_BG_COLOR)

        # Get screen dimensions
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        # Calculate window size based on percentages
        window_width = int(screen_width * WINDOW_WIDTH_PERCENT / 100)
        window_height = int(screen_height * WINDOW_HEIGHT_PERCENT / 100)
        min_width = int(screen_width * MIN_WIDTH_PERCENT / 100)
        min_height = int(screen_height * MIN_HEIGHT_PERCENT / 100)
        
        # Set window size and minimum size
        self.root.geometry(f"{window_width}x{window_height}")
        self.root.minsize(min_width, min_height)
        
        # Setup menu bar
        self.menu_bar = MenuBar(self.root, self)
        
        # Setup variables
        self.music_folder_path = tk.StringVar()
        self.output_file_path = tk.StringVar()
        self.input_file_path = tk.StringVar()
        self.found_songs = []
        self.missing_songs = []
        self.music_files = []
        self.entry_widgets = []  # For storing grid entries
        self.num_rows = 0  # Number of rows in the grid
        
        # Create the UI
        self.create_ui()

    def create_ui(self):
        # Main frame
        self.main_frame = ttk.Frame(self.root, padding=10)
        self.main_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)

        # Input section
        input_frame = ttk.Frame(self.main_frame, padding=10)
        input_frame.grid(row=0, column=0, columnspan=1, sticky=tk.NSEW)
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(0, weight=0)

        # White box for "Select a Music Folder"
        music_folder_frame = ttk.Frame(input_frame, style="WhiteFrame.TFrame", relief=tk.SOLID, borderwidth=1, padding=5)
        music_folder_frame.grid(row=0, column=0, columnspan=3, sticky=tk.NSEW, pady=5)
        input_frame.rowconfigure(0, weight=0)
        input_frame.columnconfigure(0, weight=1)  # Make sure the frame spans the width

        ttk.Label(music_folder_frame, text="Select a Music Folder", style="Heading.TLabel").grid(row=0, column=0, columnspan=3, pady=5, sticky=tk.W)

        # Music folder selection
        ttk.Label(music_folder_frame, text="Music Folder Path:").grid(row=1, column=0, sticky=tk.W, pady=5)
        
        # Configure columns for proper spacing
        music_folder_frame.columnconfigure(0, weight=0)  # Label column - fixed width
        music_folder_frame.columnconfigure(1, weight=1)  # Entry field - expands
        music_folder_frame.columnconfigure(2, weight=0)  # Button column - fixed width
        
        ttk.Entry(music_folder_frame, textvariable=self.music_folder_path).grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(music_folder_frame, text="Browse...", command=self.select_music_folder, style="Custom.TButton").grid(row=1, column=2, padx=5, pady=5)
        
        self.input_notebook = ttk.Notebook(input_frame)
        self.input_notebook.grid(row=2, column=0, columnspan=3, sticky=tk.NSEW, pady=5)
        input_frame.columnconfigure(0, weight=1)
        input_frame.rowconfigure(2, weight=1)

        # Enter Manually tab
        self.spreadsheet_tab = ttk.Frame(self.input_notebook)
        self.input_notebook.add(self.spreadsheet_tab, text="Enter Manually")
        self.spreadsheet_tab.columnconfigure(0, weight=1)
        
        # Create the grid table for data entry
        self.create_spreadsheet_view()

        # File input tab
        self.file_input_tab = ttk.Frame(self.input_notebook)
        self.input_notebook.add(self.file_input_tab, text="From File")
        self.file_input_tab.columnconfigure(0, weight=0)  # Label column
        self.file_input_tab.columnconfigure(1, weight=1)  # Entry column - expands
        self.file_input_tab.columnconfigure(2, weight=0)  # Button column
        
        ttk.Label(self.file_input_tab, text="Select Song List CSV File", style="Heading.TLabel").grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Label(self.file_input_tab, text="Song List File Path:", style="TLabel").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        ttk.Entry(self.file_input_tab, textvariable=self.input_file_path).grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(self.file_input_tab, text="Browse...", command=self.select_input_file, style="Custom.TButton").grid(row=1, column=2, padx=10, pady=5)
        ttk.Label(self.file_input_tab, text="Note: First row of CSV file must contain 'Song' and 'Artist' for the respective columns. (See Help > About for more info.)", style="TLabel").grid(row=2, column=0, columnspan=3, sticky=tk.W, padx=5, pady=5)

        # Bind notebook tab selection to toggle method
        self.input_notebook.bind("<<NotebookTabChanged>>", self.toggle_input_method)

        # White box for "Output Report File"
        output_frame = ttk.Frame(input_frame, style="WhiteFrame.TFrame", relief=tk.SOLID, borderwidth=1, padding=5)
        output_frame.grid(row=3, column=0, columnspan=3, sticky=tk.NSEW, pady=5)
        input_frame.rowconfigure(3, weight=0)
        
        # Configure columns for proper spacing in output frame
        output_frame.columnconfigure(0, weight=0)  # Label column - fixed width
        output_frame.columnconfigure(1, weight=1)  # Entry field - expands
        output_frame.columnconfigure(2, weight=0)  # Button column - fixed width

        ttk.Label(output_frame, text="Create Output Report File", style="Heading.TLabel").grid(row=0, column=0, columnspan=3, pady=5, sticky=tk.W)
        ttk.Label(output_frame, text="Output Report File Path:", style="TLabel").grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Entry(output_frame, textvariable=self.output_file_path).grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(output_frame, text="Browse...", command=self.select_output_file, style="Custom.TButton").grid(row=1, column=2, padx=5, pady=5)

        # Action buttons
        button_frame = ttk.Frame(self.main_frame)
        button_frame.grid(row=1, column=0, sticky=tk.EW, pady=10)  # Added padding to prevent overlap
        self.main_frame.rowconfigure(1, weight=0)
        
        # Create a container for the buttons to center them
        button_container = ttk.Frame(button_frame)
        button_container.pack(side=tk.TOP, fill=tk.NONE, expand=True)
        
        ttk.Button(button_container, text="Scan Music Files", command=self.scan_music_files, style="Custom.TButton", width=20).pack(side=tk.LEFT, padx=10)
        ttk.Button(button_container, text="Compare and Generate Report", command=self.compare_files, style="Custom.TButton", width=30).pack(side=tk.LEFT, padx=10)
        ttk.Button(button_container, text="Clear Log / Results", command=self.clear_results, style="Custom.TButton", width=20).pack(side=tk.LEFT, padx=10)

        # Results section with notebook tabs
        notebook = ttk.Notebook(self.main_frame)
        notebook.grid(row=2, column=0, sticky=tk.NSEW, pady=5)  # Added padding to prevent overlap
        self.main_frame.rowconfigure(2, weight=1)

        # Tab for log
        log_frame = ttk.Frame(notebook)
        notebook.add(log_frame, text="Log")
        
        self.log_text = scrolledtext.ScrolledText(log_frame, wrap=tk.WORD, bg=ENTRY_BG_COLOR, fg=INPUT_TEXT_COLOR)
        self.log_text.pack(fill=tk.BOTH, expand=True)

        # Tab for found songs
        found_frame = ttk.Frame(notebook)
        notebook.add(found_frame, text="Found Songs")
        
        self.found_text = scrolledtext.ScrolledText(found_frame, wrap=tk.WORD, bg=ENTRY_BG_COLOR, fg=INPUT_TEXT_COLOR)
        self.found_text.pack(fill=tk.BOTH, expand=True)

        # Tab for missing songs
        missing_frame = ttk.Frame(notebook)
        notebook.add(missing_frame, text="Missing Songs")
        
        self.missing_text = scrolledtext.ScrolledText(missing_frame, wrap=tk.WORD, bg=ENTRY_BG_COLOR, fg=INPUT_TEXT_COLOR)
        self.missing_text.pack(fill=tk.BOTH, expand=True)

        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.FLAT, background=MAIN_BG_COLOR, foreground=TEXT_COLOR)
        status_bar.grid(row=1, column=0, sticky=tk.EW)
        self.root.rowconfigure(1, weight=0)

        # Initial tab selection
        self.toggle_input_method(None)

        # Show window after UI is created
        self.root.deiconify()

    def set_window_icon(self, window):
        """Set the window icon for any Tkinter window"""
        try:
            # When running as a script
            if hasattr(sys, '_MEIPASS'):  # If packaged with PyInstaller
                icon_path = os.path.join(sys._MEIPASS, 'img', 'icon.ico')
            else:
                # For development environment
                script_dir = os.path.dirname(os.path.abspath(__file__))
                icon_path = os.path.join(script_dir, 'img', 'icon.ico')
            
            window.iconbitmap(icon_path)
        except Exception as e:
            print(f"Could not set window icon: {str(e)}")

    def create_spreadsheet_view(self):
        """Create a grid-like control for entering song data"""
        # Use a single frame for both headers and entries to ensure alignment
        main_content_frame = ttk.Frame(self.spreadsheet_tab, style="TFrame")
        main_content_frame.grid(row=1, column=0, columnspan=3, sticky=tk.NSEW)
        self.spreadsheet_tab.columnconfigure(0, weight=1)
        self.spreadsheet_tab.rowconfigure(1, weight=1)

        # Headers
        ttk.Label(main_content_frame, text="Enter Song List", 
                style="Heading.TLabel").grid(row=0, column=0, columnspan=3, pady=5, sticky=tk.W)
        ttk.Label(main_content_frame, text="Note: Enter manually, or paste rows from Excel, ChatGPT table, etc. (See Help > About for more info.)",
                style="TLabel").grid(row=1, column=0, columnspan=3, padx=5, pady=5, sticky=tk.W)
        # Column headers row
        header_frame = ttk.Frame(main_content_frame)
        header_frame.grid(row=2, column=0, columnspan=3, sticky=tk.EW)
        header_frame.columnconfigure(0, weight=1)  # Song column
        header_frame.columnconfigure(1, weight=1)  # Artist column
        
        ttk.Label(header_frame, text="Song Name", font=('Helvetica', 10, 'bold'), 
                foreground=TEXT_COLOR).grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        ttk.Label(header_frame, text="Artist Name", font=('Helvetica', 10, 'bold'), 
                foreground=TEXT_COLOR).grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)

        # Configure columns in the main content frame
        main_content_frame.columnconfigure(0, weight=1)  # This ensures the content expands with the window

        # Create a frame to hold the grid entries with scrollbar
        table_container = ttk.Frame(main_content_frame, style="TFrame")
        table_container.grid(row=3, column=0, columnspan=3, sticky=tk.NSEW, pady=5)
        main_content_frame.rowconfigure(2, weight=1)

        # Create canvas for scrolling with ROW_FRAME_HEIGHT
        self.canvas = tk.Canvas(table_container, bg=MAIN_BG_COLOR, highlightthickness=0, height=ROW_FRAME_HEIGHT)
        scrollbar = ttk.Scrollbar(table_container, orient="vertical", command=self.canvas.yview, style="TScrollbar")
        self.scrollable_frame = ttk.Frame(self.canvas, style="TFrame")
        
        # Set the width of the canvas to match the width of the table container
        self.scrollable_frame.bind("<Configure>", self.on_frame_configure)
        
        # Create window inside canvas that will be scrollable
        self.canvas_window = self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        
        # Bind the canvas to resize the inner window when the canvas is resized
        self.canvas.bind("<Configure>", self.on_canvas_configure)
        
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        self.canvas.grid(row=0, column=0, sticky=tk.NSEW)
        scrollbar.grid(row=0, column=1, sticky=tk.NS)
        table_container.columnconfigure(0, weight=1)
        table_container.rowconfigure(0, weight=1)
        
        # Configure columns in the scrollable frame to ensure proper sizing
        # This is critical for making the entries span the entire width
        self.scrollable_frame.columnconfigure(0, weight=1, minsize=200)  # Song column - with minimum width
        self.scrollable_frame.columnconfigure(1, weight=1, minsize=200)  # Artist column - with minimum width

        # Add initial rows
        self.num_rows = 25
        self.entry_widgets = []
        
        for i in range(self.num_rows):
            self.add_entry_row(i)
        
        # Add both buttons on the bottom row
        button_frame = ttk.Frame(self.spreadsheet_tab)
        button_frame.grid(row=3, column=0, columnspan=3, sticky=tk.EW, pady=10)
        
        # Configure columns to place buttons at the edges
        button_frame.columnconfigure(0, weight=0)  # Left button column
        button_frame.columnconfigure(1, weight=1)  # Empty space
        button_frame.columnconfigure(2, weight=0)  # Right button column
        
        # Add More Rows button (left side)
        ttk.Button(button_frame, text="Add More Rows", command=self.add_more_rows, 
                style="Custom.TButton").grid(row=0, column=0, padx=10, sticky=tk.W)
        
        # Clear All Input button (right side)
        ttk.Button(button_frame, text="Clear", command=self.clear_input, 
                style="Custom.TButton").grid(row=0, column=2, padx=10, sticky=tk.E)

        # Set up copy-paste binding for the table
        self.root.bind("<Control-v>", self.handle_paste)

    def on_frame_configure(self, event=None):
        """Handle the scrollable frame being resized"""
        # Update the scrollregion to encompass the inner frame
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def on_canvas_configure(self, event=None):
        """Handle the canvas being resized"""
        # Resize the inner frame to match the canvas width
        width = event.width
        self.canvas.itemconfig(self.canvas_window, width=width)

    def add_entry_row(self, row_idx):
        """Add a row of entry widgets to the grid"""
        song_entry = ttk.Entry(self.scrollable_frame, style="TEntry")
        song_entry.grid(row=row_idx, column=0, padx=2, pady=1, sticky=tk.EW)
        
        artist_entry = ttk.Entry(self.scrollable_frame, style="TEntry")
        artist_entry.grid(row=row_idx, column=1, padx=2, pady=1, sticky=tk.EW)
        
        # Setup tabbing between entries
        song_entry.bind("<Tab>", lambda e, next_w=artist_entry: next_w.focus_set())
        if row_idx > 0:
            prev_artist = self.entry_widgets[-1][1]
            prev_artist.bind("<Tab>", lambda e, next_w=song_entry: next_w.focus_set())
        
        self.entry_widgets.append((song_entry, artist_entry))

    def add_more_rows(self):
        """Add 10 more rows to the grid"""
        for i in range(self.num_rows, self.num_rows + 10):
            self.add_entry_row(i)
        self.num_rows += 10
        self.canvas.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def clear_input(self):
        """Clear all input fields in the Enter Manually"""
        for song_entry, artist_entry in self.entry_widgets:
            song_entry.delete(0, tk.END)
            artist_entry.delete(0, tk.END)
        self.log_message("All input fields cleared")
             
    def handle_paste(self, event):
        """Handle pasting from clipboard"""
        try:
            widget = self.root.focus_get()
            if not isinstance(widget, ttk.Entry):
                return
            clipboard = self.root.clipboard_get()
            if not clipboard:
                return
            lines = clipboard.split('\n')
            if not lines:
                return
            current_row = -1
            current_col = -1
            for i, (song_entry, artist_entry) in enumerate(self.entry_widgets):
                if widget == song_entry:
                    current_row = i
                    current_col = 0
                    break
                elif widget == artist_entry:
                    current_row = i
                    current_col = 1
                    break
            if current_row == -1:
                return
            row_offset = 0
            for line in lines:
                if not line.strip():
                    continue
                if '\t' in line:
                    cells = line.split('\t')
                else:
                    try:
                        reader = csv.reader([line])
                        cells = next(reader)
                    except:
                        cells = line.split(',')
                if not cells:
                    continue
                while current_row + row_offset >= self.num_rows:
                    self.add_more_rows()
                for col_offset, cell_value in enumerate(cells):
                    col_idx = current_col + col_offset
                    if col_idx > 1:
                        break
                    if col_idx == 0:
                        self.entry_widgets[current_row + row_offset][0].delete(0, tk.END)
                        self.entry_widgets[current_row + row_offset][0].insert(0, cell_value.strip())
                    elif col_idx == 1:
                        self.entry_widgets[current_row + row_offset][1].delete(0, tk.END)
                        self.entry_widgets[current_row + row_offset][1].insert(0, cell_value.strip())
                row_offset += 1
            self.canvas.update_idletasks()
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        except Exception as e:
            self.log_message(f"Paste error: {str(e)}")
            
    def toggle_input_method(self, event):
        selected_tab = self.input_notebook.index(self.input_notebook.select())
        if selected_tab == 0:  # Enter Manually
            self.input_method = "paste"
        else:  # From File
            self.input_method = "file"
    
    def select_music_folder(self):
        folder_path = filedialog.askdirectory(title="Select Music Folder")
        if folder_path:
            self.music_folder_path.set(folder_path)
            self.log_message(f"Music folder set to: {folder_path}")
    
    def select_input_file(self):
        file_path = filedialog.askopenfilename(
            title="Select Song List File",
            filetypes=[("CSV Files", "*.csv")]
        )
        if file_path:
            if not file_path.lower().endswith('.csv'):
                messagebox.showerror("Error", "Please select a valid CSV file!")
                return
            self.input_file_path.set(file_path)
            self.log_message(f"Song list file set to: {file_path}")
    
    def select_output_file(self):
        file_path = filedialog.asksaveasfilename(
            title="Save Report As",
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        if file_path:
            self.output_file_path.set(file_path)
            self.log_message(f"Output report file set to: {file_path}")
    
    def scan_music_files(self):
        
        music_folder = self.music_folder_path.get()
        if not music_folder:
            messagebox.showerror("Error", "Please select a music folder first!")
            
            return
        
        self.status_var.set("Scanning music files...")
        self.root.update_idletasks()
        
        self.music_files = []
        self.log_message("Starting music file scan...")
        
        music_extensions = ['.mp3', '.flac', '.m4a', '.mp4', '.wma', '.ogg', '.wav']
        
        for root, _, files in os.walk(music_folder):
            for file in files:
                file_ext = os.path.splitext(file)[1].lower()
                if file_ext in music_extensions:
                    file_path = os.path.join(root, file)
                    song_info = self.extract_metadata(file_path, file_ext)
                    if song_info:
                        self.music_files.append(song_info)
        
        self.log_message(f"Scan complete. Found {len(self.music_files)} music files.")
        self.status_var.set(f"Found {len(self.music_files)} music files")
        
    
    def extract_metadata(self, file_path, file_ext):
        try:
            filename = os.path.basename(file_path)
            filename_no_ext = os.path.splitext(filename)[0]
            title = ""
            artist = ""
            if file_ext == '.mp3':
                try:
                    audio = ID3(file_path)
                    if 'TIT2' in audio:
                        title = str(audio['TIT2'])
                    if 'TPE1' in audio:
                        artist = str(audio['TPE1'])
                except (ID3NoHeaderError, Exception):
                    pass
            elif file_ext == '.flac':
                try:
                    audio = FLAC(file_path)
                    if 'title' in audio:
                        title = audio['title'][0]
                    if 'artist' in audio:
                        artist = audio['artist'][0]
                except Exception:
                    pass
            elif file_ext in ['.m4a', '.mp4']:
                try:
                    audio = MP4(file_path)
                    if '©nam' in audio:
                        title = audio['©nam'][0]
                    if '©ART' in audio:
                        artist = audio['©ART'][0]
                except Exception:
                    pass
            if title and artist:
                return {'title': title.strip(), 'artist': artist.strip(), 'path': file_path}
            artist_title_match = re.match(r'(.+) - (.+)', filename_no_ext)
            if artist_title_match:
                artist, title = artist_title_match.groups()
                return {'title': title.strip(), 'artist': artist.strip(), 'path': file_path}
            title_artist_match = re.match(r'(.+)_(.+)', filename_no_ext)
            if title_artist_match:
                title, artist = title_artist_match.groups()
                return {'title': title.strip(), 'artist': artist.strip(), 'path': file_path}
            return {'title': filename_no_ext.strip(), 'artist': '', 'path': file_path}
        except Exception as e:
            self.log_message(f"Error processing {file_path}: {str(e)}")
            return None
    
    def get_songs_to_check(self):
        songs_to_check = []
        if self.input_method == "paste":
            for song_entry, artist_entry in self.entry_widgets:
                song = song_entry.get().strip()
                artist = artist_entry.get().strip()
                if song:
                    songs_to_check.append({'title': song, 'artist': artist})
        else:
            input_file = self.input_file_path.get()
            if not input_file:
                messagebox.showerror("Error", "Please select an input song list file!")
                return None
            try:
                with open(input_file, 'r', newline='', encoding='utf-8') as csvfile:
                    reader = csv.reader(csvfile)
                    headers = next(reader, [])
                    title_idx = None
                    artist_idx = None
                    for i, header in enumerate(headers):
                        if 'song' in header.lower():
                            title_idx = i
                        elif 'artist' in header.lower():
                            artist_idx = i
                    if title_idx is None:
                        messagebox.showerror("Error", "CSV file must contain a 'Song' column in the header!")
                        return None
                    if artist_idx is None:
                        messagebox.showwarning("Warning", "No 'Artist' column found in CSV header. Artist data will be empty.")
                    for row in reader:
                        if len(row) > title_idx:
                            title = row[title_idx].strip() if title_idx is not None else ""
                            artist = row[artist_idx].strip() if artist_idx is not None and len(row) > artist_idx else ""
                            if title:
                                songs_to_check.append({'title': title, 'artist': artist})
            except Exception as e:
                self.log_message(f"Error reading input file: {str(e)}")
                messagebox.showerror("Error", f"Error reading input file: {str(e)}")
                return None
        if not songs_to_check:
            messagebox.showerror("Error", "No valid songs found in the input!")
            return None
        self.log_message(f"Loaded {len(songs_to_check)} songs to check")
        return songs_to_check

    def compare_files(self):
        """Compare song list with scanned music files and generate a detailed report"""
        if not self.music_files:
            messagebox.showerror("Error", "Please scan your music files first!")
            return
            
        output_file = self.output_file_path.get()
        if not output_file:
            messagebox.showerror("Error", "Please select an output report file!")
            return
            
        songs_to_check = self.get_songs_to_check()
        if not songs_to_check:
            return
            
        # Update status
        self.status_var.set("Comparing files...")
        self.root.update_idletasks()
        
        # Clear previous results
        self.found_songs = []
        self.missing_songs = []
        
        # Log the start of comparison
        self.log_message("Starting comparison...")
        
        # Compare each song in the input list with the music files
        for song in songs_to_check:
            found = False
            for music_file in self.music_files:
                title_match = song['title'].lower() == music_file['title'].lower()
                artist_match = True
                if song['artist'] and music_file['artist']:
                    artist_match = song['artist'].lower() == music_file['artist'].lower()
                if title_match and artist_match:
                    self.found_songs.append({
                        'title': song['title'], 
                        'artist': song['artist'], 
                        'path': music_file['path']
                    })
                    found = True
                    break
            if not found:
                self.missing_songs.append({'title': song['title'], 'artist': song['artist']})
        
        # Get current date and time for the report
        from datetime import datetime
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Write the enhanced report
        with open(output_file, 'w', encoding='utf-8') as f:
            # Report header with time, date, and paths
            f.write("==================================================================\n")
            f.write("                   MUSIC COLLECTION ANALYSIS REPORT                \n")
            f.write("==================================================================\n\n")
            
            f.write(f"Report Generated: {current_time}\n\n")
            
            # Paths used for analysis
            f.write("PATHS USED:\n")
            f.write(f"Music Folder: {self.music_folder_path.get()}\n")
            if self.input_method == "file":
                f.write(f"Input Songs File: {self.input_file_path.get()}\n")
            f.write(f"Output Report File: {output_file}\n\n")
            
            # Summary statistics
            f.write("SUMMARY:\n")
            f.write(f"Total songs checked: {len(songs_to_check)}\n")
            f.write(f"Songs found in music folder: {len(self.found_songs)}\n")
            f.write(f"Songs NOT found in music folder: {len(self.missing_songs)}\n\n")
            
            # Divider for readability
            f.write("==================================================================\n\n")
            
            # Input songs section
            f.write("INPUT SONGS LIST:\n")
            f.write("-----------------\n")
            for i, song in enumerate(songs_to_check, 1):
                artist_info = f" by '{song['artist']}'" if song['artist'] else ""
                f.write(f"{i}. '{song['title']}'{artist_info}\n")
            
            # Divider for readability
            f.write("\n==================================================================\n\n")
            
            # Found songs section with more descriptive title
            f.write("SONGS THAT ALREADY EXIST IN MUSIC FOLDER:\n")
            f.write("------------------------------------------\n")
            if self.found_songs:
                for i, song in enumerate(self.found_songs, 1):
                    artist_info = f" by '{song['artist']}'" if song['artist'] else ""
                    f.write(f"{i}. '{song['title']}'{artist_info}\n")
                    f.write(f"   Location: {song['path']}\n\n")
            else:
                f.write("None of the requested songs were found in your music collection.\n")
            
            # Divider for readability
            f.write("\n==================================================================\n\n")
            
            # Missing songs section with more descriptive title
            f.write("SONGS THAT DO NOT EXIST IN MUSIC FOLDER (ADD THESE):\n")
            f.write("----------------------------------------------------\n")
            if self.missing_songs:
                for i, song in enumerate(self.missing_songs, 1):
                    artist_info = f" by '{song['artist']}'" if song['artist'] else ""
                    f.write(f"{i}. '{song['title']}'{artist_info}\n")
                
            else:
                f.write("All requested songs were found in your music collection. Congratulations!\n")
        
            # Footer
            f.write("\n==================================================================\n")
            f.write("End of Report\n")
        
        # Update the UI with results
        self.update_results_display()
        
        # Log completion
        self.log_message(f"Comparison complete. Report saved to {output_file}")
        self.status_var.set("Comparison complete")
        
        # Show success message
        messagebox.showinfo("Success", 
                        f"Analysis complete!\n\n"
                        f"Songs found: {len(self.found_songs)}\n"
                        f"Songs missing: {len(self.missing_songs)}\n\n"
                        f"Report saved to:\n{output_file}", 
                        parent=self.root)
    
    def update_results_display(self):
        self.found_text.delete(1.0, tk.END)
        for song in self.found_songs:
            self.found_text.insert(tk.END, f"'{song['title']}','{song['artist']}' - {song['path']}\n")
        self.missing_text.delete(1.0, tk.END)
        for song in self.missing_songs:
            self.missing_text.insert(tk.END, f"'{song['title']}','{song['artist']}'\n")
    
    def clear_results(self):
        self.log_text.delete(1.0, tk.END)
        self.found_text.delete(1.0, tk.END)
        self.missing_text.delete(1.0, tk.END)
        self.found_songs = []
        self.missing_songs = []
        self.log_message("Results cleared")
        self.status_var.set("Ready")
    
    def log_message(self, message):
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.see(tk.END)
        print(message)

if __name__ == "__main__":
    root = tk.Tk()
    app = MusicAnalyzer(root)
    root.mainloop()