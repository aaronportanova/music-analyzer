
README


NAME: Music Collection Analyzer
TYPE: Application

--

ABOUT:
This application compares a list of songs to existing music files in your music folder, and generates 
a report of songs that exist already, and songs that don't.

USAGE:
- Go to the "_app" folder and click on 'Music Collection Analyzer' to launch the application.
- Ignore the 'build' and 'src' folders; ignore the 'Music Collection Analyzer.spec' file.

HELP:
After launching the program, click on 'Help > About' in the menubar for usage notes.

--

Aaron Portanova
March 2025